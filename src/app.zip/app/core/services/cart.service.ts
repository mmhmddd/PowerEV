// src/app/core/services/cart.service.ts
import { Injectable, PLATFORM_ID, Inject } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Observable, BehaviorSubject, throwError } from 'rxjs';
import { tap, map, catchError } from 'rxjs/operators';
import { ApiEndpoints } from '../constants/api-endpoints';
import { Cart, CartResponse } from '../models/product.models';

export interface AddToCartRequest {
  productId: string;
  productType: 'Charger' | 'Cable' | 'Station' | 'Adapter' | 'Box' | 'Breaker' | 'Plug' | 'Wire' | 'Other';
  quantity?: number;
}

export interface UpdateCartItemRequest {
  productId: string;
  productType: string;
  quantity: number;
}

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private sessionId: string;
  private cartSubject = new BehaviorSubject<Cart | null>(null);
  public cart$ = this.cartSubject.asObservable();
  private isBrowser: boolean;

  constructor(
    private http: HttpClient,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {
    this.isBrowser = isPlatformBrowser(this.platformId);
    this.sessionId = this.getOrCreateSessionId();

    // Delay cart loading to avoid circular dependency during initialization
    if (this.isBrowser) {
      // Use setTimeout to break circular dependency chain
      setTimeout(() => this.loadCart(), 0);
    }
  }

  private getOrCreateSessionId(): string {
    // Return a temporary ID if not in browser (SSR scenario)
    if (!this.isBrowser) {
      return 'ssr-temp-session-' + Date.now();
    }

    try {
      let sessionId = localStorage.getItem('cartSessionId');
      if (!sessionId) {
        sessionId = this.generateUUID();
        localStorage.setItem('cartSessionId', sessionId);
      }
      return sessionId;
    } catch (error) {
      console.error('Error accessing localStorage:', error);
      // Fallback if localStorage is restricted
      return 'fallback-session-' + Date.now();
    }
  }

  /**
   * Generate UUID v4 (RFC4122 compliant)
   */
  private generateUUID(): string {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      const r = Math.random() * 16 | 0;
      const v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }

  /**
   * Normalize cart data to ensure totalPrice is set
   * Backend sends totalAmount, frontend expects totalPrice
   */
  private normalizeCart(cart: any): Cart {
    const normalized = {
      ...cart,
      totalPrice: cart.totalAmount || cart.totalPrice || 0
    };

    // Ensure items is always an array
    if (!normalized.items || !Array.isArray(normalized.items)) {
      normalized.items = [];
    }

    return normalized as Cart;
  }

  /**
   * Load cart for current session
   * Creates empty cart if doesn't exist
   */
  loadCart(): void {
    // Skip loading in SSR environment
    if (!this.isBrowser) {
      console.log('CartService: Skipping cart load in SSR environment');
      return;
    }

    this.getCart(this.sessionId).subscribe({
      next: (response) => {
        if (response.success && response.data) {
          const normalizedCart = this.normalizeCart(response.data);
          this.cartSubject.next(normalizedCart);
          console.log('Cart loaded:', normalizedCart);
        }
      },
      error: (error) => {
        console.error('Error loading cart:', error);
        // Create empty cart on error
        this.cartSubject.next({
          _id: '',
          sessionId: this.sessionId,
          items: [],
          totalPrice: 0
        });
      }
    });
  }

  /**
   * Get cart by session ID
   * Backend creates empty cart if not exists
   * @param sessionId - Session ID
   * @returns Observable of cart response
   */
  getCart(sessionId: string): Observable<CartResponse> {
    return this.http.get<CartResponse>(ApiEndpoints.cart.get(sessionId)).pipe(
      map(response => {
        if (response.success && response.data) {
          response.data = this.normalizeCart(response.data);
        }
        return response;
      }),
      catchError(error => {
        console.error('Get cart error:', error);
        return throwError(() => error);
      })
    );
  }

  /**
   * Add item to cart
   * Required: productId, productType
   * Optional: quantity (defaults to 1)
   * Backend validates stock availability
   * @param item - Cart item data
   * @returns Observable of cart response
   */
  addToCart(item: AddToCartRequest): Observable<CartResponse> {
    console.log('CartService: Adding to cart:', item);
    return this.http.post<CartResponse>(
      ApiEndpoints.cart.addItem(this.sessionId),
      item
    ).pipe(
      map(response => {
        console.log('CartService: Add to cart response:', response);
        if (response.success && response.data) {
          response.data = this.normalizeCart(response.data);
        }
        return response;
      }),
      tap(response => {
        if (response.success && response.data) {
          this.cartSubject.next(response.data);
        }
      }),
      catchError(error => {
        console.error('Add to cart error:', error);
        return throwError(() => error);
      })
    );
  }

  /**
   * Update cart item quantity
   * Required: productId, productType, quantity
   * Backend validates stock availability
   * @param productId - Product ID
   * @param productType - Product type
   * @param quantity - New quantity
   * @returns Observable of cart response
   */
  updateCartItem(productId: string, productType: string, quantity: number): Observable<CartResponse> {
    return this.http.put<CartResponse>(
      ApiEndpoints.cart.updateItem(this.sessionId),
      { productId, productType, quantity }
    ).pipe(
      map(response => {
        if (response.success && response.data) {
          response.data = this.normalizeCart(response.data);
        }
        return response;
      }),
      tap(response => {
        if (response.success && response.data) {
          this.cartSubject.next(response.data);
        }
      }),
      catchError(error => {
        console.error('Update cart item error:', error);
        return throwError(() => error);
      })
    );
  }

  /**
   * Remove item from cart
   * @param productId - Product ID
   * @param productType - Product type
   * @returns Observable of cart response
   */
  removeFromCart(productId: string, productType: string): Observable<CartResponse> {
    return this.http.delete<CartResponse>(
      ApiEndpoints.cart.removeItem(this.sessionId, productId, productType)
    ).pipe(
      map(response => {
        if (response.success && response.data) {
          response.data = this.normalizeCart(response.data);
        }
        return response;
      }),
      tap(response => {
        if (response.success && response.data) {
          this.cartSubject.next(response.data);
        }
      }),
      catchError(error => {
        console.error('Remove from cart error:', error);
        return throwError(() => error);
      })
    );
  }

  /**
   * Clear entire cart
   * Sets items to empty array and totalPrice to 0
   * @returns Observable of cart response
   */
  clearCart(): Observable<CartResponse> {
    return this.http.delete<CartResponse>(
      ApiEndpoints.cart.clear(this.sessionId)
    ).pipe(
      map(response => {
        if (response.success && response.data) {
          response.data = this.normalizeCart(response.data);
        }
        return response;
      }),
      tap(response => {
        if (response.success && response.data) {
          this.cartSubject.next(response.data);
        }
      }),
      catchError(error => {
        console.error('Clear cart error:', error);
        return throwError(() => error);
      })
    );
  }

  /**
   * Get total number of items in cart
   * @returns Total item count
   */
  getCartItemCount(): number {
    const cart = this.cartSubject.value;
    return cart?.items.reduce((total, item) => total + item.quantity, 0) || 0;
  }

  /**
   * Get cart total amount
   * @returns Total cart amount
   */
  getCartTotal(): number {
    const cart = this.cartSubject.value;
    return cart?.totalPrice || 0;
  }

  /**
   * Get current session ID
   * @returns Session ID
   */
  getSessionId(): string {
    return this.sessionId;
  }

  /**
   * Get current cart value
   * @returns Cart or null
   */
  getCurrentCart(): Cart | null {
    return this.cartSubject.value;
  }

  /**
   * Check if running in browser environment
   * @returns boolean
   */
  isInBrowser(): boolean {
    return this.isBrowser;
  }
}
